function toggleDetails() {
    const details = document.getElementById('experience-details');
    // Toggle the 'open' attribute of the details element
    if (details.hasAttribute('open')) {
    details.removeAttribute('open');
    } else {
    details.setAttribute('open', 'open');
    }
}
function toggleDetailsOne() {
    const details = document.getElementById('experience-details-one');
    // Toggle the 'open' attribute of the details element
    if (details.hasAttribute('open')) {
    details.removeAttribute('open');
    } else {
    details.setAttribute('open', 'open');
    }
}
function toggleDetailsTwo() {
    const details = document.getElementById('experience-details-two');
    // Toggle the 'open' attribute of the details element
    if (details.hasAttribute('open')) {
    details.removeAttribute('open');
    } else {
    details.setAttribute('open', 'open');
    }
}
